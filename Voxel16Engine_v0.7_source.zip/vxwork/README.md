# Voxel16 Engine — prototipo voxel Android ARM64 (v0.7)

Motor independiente de demostración. No es Minecraft ni contiene código propietario de Mojang. El objetivo es construir un juego voxel Android 64-bit y añadir compatibilidad con formatos abiertos/documentados de forma progresiva.

## En esta versión
- App Android Kotlin + C++20/JNI y OpenGL ES 3.
- ABI `arm64-v8a`, `minSdk 26`, `targetSdk 36`.
- Terreno procedural 48×48, capas de bloques, árboles y hojas.
- Cámara táctil, movimiento, gravedad y salto básicos.
- Romper/colocar bloques con inventario por cantidades.
- Ocho materiales seleccionables: césped, tierra, piedra, madera, hojas, arena, agua (todavía bloque sólido) y tablas.
- Receta de fabricación: 2 maderas → 4 tablas.
- Criatura de prueba móvil con IA sencilla: patrulla y persigue al jugador cuando está cerca.
- Combate cuerpo a cuerpo: criatura con 5 puntos de vida, efecto de daño y recompensa de 2 piedras al derrotarla. Si se acerca, ataca al jugador y le quita 2 puntos cada 1,25 s; al llegar a cero, el jugador reaparece en el punto inicial con 20 puntos de vida. HUD con vida del jugador y de la criatura.
- Ciclo día/noche visual mediante cambio de color del cielo.
- Guardado/carga de mundo, inventario y salud en `filesDir/world.vxw`; formato VXW4 con lectura compatible de partidas VXW1, VXW2 y VXW3; ahora conserva también la posición y dirección de la criatura.
- Geometría por caras visibles para reducir triángulos.

## Limitaciones que siguen pendientes
- No se ha compilado ni ejecutado en dispositivo en este entorno. El ZIP es código fuente, no APK. Este entorno no tiene Android SDK/NDK ni Gradle instalados. Se añadió un flujo de GitHub Actions para generar un APK debug ARM64 al subir el proyecto a un repositorio y ejecutar la acción Android APK.
- No implementa todavía mundos `.mcworld`, paquetes `.mcpack`, Resource Packs, Behavior Packs ni Script API de Bedrock. Para admitirlos no basta con cambiar la extensión: hay que implementar sus formatos, recursos y APIs compatibles.
- No es posible sustituir el motor propietario de Minecraft 1.18.32 con bibliotecas de otra versión.
- Agua sin transparencia/flujo; iluminación del mundo simplificada; sin sonido, multijugador, aldeanos, combate avanzado ni mobs articulados.
- El inventario inicial es de prueba y no representa una economía/supervivencia completa.

## Compilar
### Android Studio
1. Abrir la carpeta `vxwork` en Android Studio reciente.
2. Instalar SDK Platform 36, NDK side-by-side y CMake 3.22.1.
3. Sincronizar Gradle y compilar la variante `debug`.
4. Instalar el APK de depuración en un dispositivo ARM64 con Android 8 o superior.
5. Probar controles, inventario, fabricación, guardado/carga y revisar Logcat si falla.

### Compilación automática
1. Crear un repositorio GitHub y subir el contenido de esta carpeta (la carpeta raíz contiene `settings.gradle.kts`).
2. Abrir la pestaña Actions y ejecutar `Android APK` (también se ejecuta al hacer push a `main` o `master`).
3. Descargar el artefacto `Voxel16Engine-debug-arm64`; contiene `app-debug.apk`.

## Próximos hitos técnicos
1. Más tipos de criaturas y modelos articulados.
2. Texturas PNG y atlas UV con carga de paquetes de recursos propios.
3. Física de agua/transparencia y luces por vértice.
4. Importador seguro de ZIP/JSON para recursos propios y formatos Bedrock documentados, sin prometer compatibilidad total con Script API.
