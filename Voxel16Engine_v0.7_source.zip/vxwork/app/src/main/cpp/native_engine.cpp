#include <jni.h>
#include <GLES3/gl3.h>
#include <android/log.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,"Voxel16",__VA_ARGS__)

namespace {
constexpr int W=48, D=48, H=24;
enum Block : uint8_t { AIR=0, GRASS=1, DIRT=2, STONE=3, WOOD=4, LEAVES=5, SAND=6, WATER=7, MOB=8, PLANK=9 };
std::vector<uint8_t> world(W*D*H,0);
std::string savePath;
GLuint program=0,vbo=0;
GLint mvpLoc=-1;
int width=1,height=1;
float yaw=0,pitch=-22,playerX=24,playerY=12,playerZ=24,velY=0;
int selected=1;
std::array<int,10> inventory={0,32,32,24,12,16,12,8,0,0};
float mobX=16.0f,mobY=7.0f,mobZ=18.0f,mobDir=1.0f;
int mobHealth=5;
int playerHealth=20;
float mobHurt=0.0f;
float mobAttackCooldown=0.0f;
float worldClock=0.0f;
std::vector<float> verts;
float lastMoveX=0,lastMoveZ=0;
inline int idx(int x,int y,int z){return (y*D+z)*W+x;}
inline bool inside(int x,int y,int z){return x>=0&&x<W&&z>=0&&z<D&&y>=0&&y<H;}
uint8_t get(int x,int y,int z){return inside(x,y,z)?world[idx(x,y,z)]:AIR;}
void set(int x,int y,int z,uint8_t b){if(inside(x,y,z))world[idx(x,y,z)]=b;}
const char* VS=R"(#version 300 es
layout(location=0) in vec3 aPos; layout(location=1) in vec3 aColor;
uniform mat4 uMVP; out vec3 color;
void main(){color=aColor;gl_Position=uMVP*vec4(aPos,1.0);})";
const char* FS=R"(#version 300 es
precision mediump float; in vec3 color; out vec4 frag;
void main(){frag=vec4(color,1.0);})";
GLuint shader(GLenum t,const char*s){GLuint q=glCreateShader(t);glShaderSource(q,1,&s,nullptr);glCompileShader(q);GLint ok=0;glGetShaderiv(q,GL_COMPILE_STATUS,&ok);if(!ok){char l[1024];glGetShaderInfoLog(q,1024,nullptr,l);LOGE("shader %s",l);glDeleteShader(q);return 0;}return q;}
void tri(const float*a,const float*b,const float*c,float r,float g,float bl){
 for(auto p:{a,b,c})verts.insert(verts.end(),{p[0],p[1],p[2],r,g,bl});
}
void face(float x,float y,float z,int s,uint8_t block){
 float q[6][4][3]={
 {{x,y+1,z},{x+1,y+1,z},{x+1,y+1,z+1},{x,y+1,z+1}},
 {{x,y,z+1},{x+1,y,z+1},{x+1,y,z},{x,y,z}},
 {{x,y,z},{x,y+1,z},{x,y+1,z+1},{x,y,z+1}},
 {{x+1,y,z+1},{x+1,y+1,z+1},{x+1,y+1,z},{x+1,y,z}},
 {{x,y,z+1},{x,y+1,z+1},{x+1,y+1,z+1},{x+1,y,z+1}},
 {{x+1,y,z},{x+1,y+1,z},{x,y+1,z},{x,y,z}}};
 float r=.38f,g=.35f,b=.28f;
 switch(block){case GRASS:r=.24f;g=.62f;b=.20f;break;case DIRT:r=.48f;g=.30f;b=.16f;break;case STONE:r=.48f;g=.49f;b=.52f;break;case WOOD:r=.48f;g=.29f;b=.12f;break;case LEAVES:r=.13f;g=.43f;b=.16f;break;case SAND:r=.78f;g=.69f;b=.42f;break;case WATER:r=.12f;g=.38f;b=.82f;break;case MOB:r=mobHurt>0.0f?.95f:.12f;g=mobHurt>0.0f?.12f:.58f;b=mobHurt>0.0f?.10f:.18f;break;case PLANK:r=.68f;g=.46f;b=.23f;break;}
 float shade[6]={1,.55f,.72f,.72f,.84f,.62f};r*=shade[s];g*=shade[s];b*=shade[s];
 tri(q[s][0],q[s][1],q[s][2],r,g,b);tri(q[s][0],q[s][2],q[s][3],r,g,b);
}
void terrain(){
 std::fill(world.begin(),world.end(),0);
 for(int x=0;x<W;x++)for(int z=0;z<D;z++){
  int h=5+(int)(2.4f*sinf(x*.18f)*cosf(z*.16f)+1.8f*sinf((x+z)*.11f));
  h=std::clamp(h,2,11);
  for(int y=0;y<h;y++)set(x,y,z,y==h-1?GRASS:(y>h-4?DIRT:STONE));
  if((x*17+z*31)%97==0 && h+5<H){
   for(int y=h;y<h+4;y++)set(x,y,z,WOOD);
   for(int dx=-2;dx<=2;dx++)for(int dz=-2;dz<=2;dz++)for(int dy=2;dy<=5;dy++)
    if(abs(dx)+abs(dz)+(dy==5?2:0)<5 && get(x+dx,h+dy,z+dz)==AIR)set(x+dx,h+dy,z+dz,LEAVES);
  }
 }
}
void mesh(){
 verts.clear();
 for(int y=0;y<H;y++)for(int z=0;z<D;z++)for(int x=0;x<W;x++){
  uint8_t b=get(x,y,z);if(!b)continue;
  if(!get(x,y+1,z))face(x,y,z,0,b);
  if(!get(x,y-1,z))face(x,y,z,1,b);
  if(!get(x-1,y,z))face(x,y,z,2,b);
  if(!get(x+1,y,z))face(x,y,z,3,b);
  if(!get(x,y,z+1))face(x,y,z,4,b);
  if(!get(x,y,z-1))face(x,y,z,5,b);
 }
 // La criatura desaparece visualmente cuando su salud llega a cero.
 if(mobHealth>0) for(int side=0;side<6;side++) face(mobX,mobY,mobZ,side,MOB);
 glBindBuffer(GL_ARRAY_BUFFER,vbo);
 glBufferData(GL_ARRAY_BUFFER,verts.size()*sizeof(float),verts.data(),GL_DYNAMIC_DRAW);
}
void ident(float*m){std::fill(m,m+16,0);m[0]=m[5]=m[10]=m[15]=1;}
void mul(float*o,const float*a,const float*b){for(int c=0;c<4;c++)for(int r=0;r<4;r++){o[c*4+r]=0;for(int k=0;k<4;k++)o[c*4+r]+=a[k*4+r]*b[c*4+k];}}
void perspective(float*m,float fovy,float asp,float n,float f){std::fill(m,m+16,0);float q=1/tanf(fovy/2);m[0]=q/asp;m[5]=q;m[10]=(f+n)/(n-f);m[11]=-1;m[14]=2*f*n/(n-f);}
void rx(float*m,float a){ident(m);float c=cosf(a),s=sinf(a);m[5]=c;m[6]=s;m[9]=-s;m[10]=c;}
void ry(float*m,float a){ident(m);float c=cosf(a),s=sinf(a);m[0]=c;m[2]=-s;m[8]=s;m[10]=c;}
void tr(float*m,float x,float y,float z){ident(m);m[12]=x;m[13]=y;m[14]=z;}
void rebuild(){mesh();}
void target(int&x,int&y,int&z){float cy=cosf(yaw),sy=sinf(yaw);x=(int)floorf(playerX+sy*3.0f);z=(int)floorf(playerZ-cy*3.0f);y=(int)floorf(playerY-1.0f);}
}
extern "C" JNIEXPORT void JNICALL Java_org_example_voxel16_NativeEngine_setWorldPath(JNIEnv*e,jobject,jstring p){const char*s=e->GetStringUTFChars(p,nullptr);savePath=s;e->ReleaseStringUTFChars(p,s);}
extern "C" JNIEXPORT void JNICALL Java_org_example_voxel16_NativeEngine_init(JNIEnv*,jobject){
 GLuint a=shader(GL_VERTEX_SHADER,VS),b=shader(GL_FRAGMENT_SHADER,FS);program=glCreateProgram();glAttachShader(program,a);glAttachShader(program,b);glLinkProgram(program);glDeleteShader(a);glDeleteShader(b);
 mvpLoc=glGetUniformLocation(program,"uMVP");glGenBuffers(1,&vbo);terrain();mobY=(float)(5+2);mesh();glEnable(GL_DEPTH_TEST);glDisable(GL_CULL_FACE);
}
extern "C" JNIEXPORT void JNICALL Java_org_example_voxel16_NativeEngine_resize(JNIEnv*,jobject,jint w,jint h){width=std::max(1,(int)w);height=std::max(1,(int)h);glViewport(0,0,width,height);}
extern "C" JNIEXPORT void JNICALL Java_org_example_voxel16_NativeEngine_look(JNIEnv*,jobject,jfloat dx,jfloat dy){yaw+=dx*.004f;pitch=std::clamp(pitch+dy*.12f,-75.0f,55.0f);}
extern "C" JNIEXPORT void JNICALL Java_org_example_voxel16_NativeEngine_move(JNIEnv*,jobject,jfloat x,jfloat z,jfloat dt){
 float step=std::clamp(dt,0.0f,.05f);
 float oldMob=mobX,oldMobZ=mobZ;
 mobHurt=std::max(0.0f,mobHurt-step);
 mobAttackCooldown=std::max(0.0f,mobAttackCooldown-step);
 float dx=playerX-mobX,dz=playerZ-mobZ,dist=sqrtf(dx*dx+dz*dz);
 if(mobHealth>0 && dist<12.0f && dist>1.45f){mobX+=dx/dist*step*0.55f;mobZ+=dz/dist*step*0.55f;}
 else if(mobHealth>0 && dist<=1.45f){
  if(mobAttackCooldown<=0.0f){playerHealth=std::max(0,playerHealth-2);mobAttackCooldown=1.25f;
   if(playerHealth==0){playerX=24.0f;playerY=12.0f;playerZ=24.0f;velY=0;playerHealth=20;}
  }
 } else if(mobHealth>0) {mobX+=mobDir*step*0.75f;if(mobX<8||mobX>23)mobDir=-mobDir;}
 mobY=7.0f+0.06f*sinf(worldClock*18.0f);
 if(mobHealth>0 && ((int)oldMob!=(int)mobX || (int)oldMobZ!=(int)mobZ))rebuild();
 float speed=5.2f*step,fx=sinf(yaw),fz=-cosf(yaw);
 float nx=playerX+(x*cosf(yaw)+z*fx)*speed,nz=playerZ+(-x*fx+z*cosf(yaw))*speed;
 if(get((int)nx,(int)playerY,(int)playerZ)==AIR)playerX=std::clamp(nx,1.0f,(float)W-2);
 if(get((int)playerX,(int)playerY,(int)nz)==AIR)playerZ=std::clamp(nz,1.0f,(float)D-2);
 int ground=(int)playerY;
 while(ground>1&&get((int)playerX,ground-1,(int)playerZ)==AIR)ground--;
 if(velY!=0){playerY+=velY*dt;velY-=18*dt;}
 if(playerY<ground+1){playerY=ground+1;velY=0;}
}
extern "C" JNIEXPORT void JNICALL Java_org_example_voxel16_NativeEngine_selectNextBlock(JNIEnv*,jobject,jint dir){selected+=dir;if(selected<1)selected=7;if(selected>8)selected=1;}
extern "C" JNIEXPORT void JNICALL Java_org_example_voxel16_NativeEngine_jump(JNIEnv*,jobject){if(velY==0)velY=7.0f;}
extern "C" JNIEXPORT void JNICALL Java_org_example_voxel16_NativeEngine_breakBlock(JNIEnv*,jobject){
 int x,y,z;target(x,y,z);uint8_t b=get(x,y,z);
 if(b!=AIR && b!=MOB && b<=PLANK){int item=(b==PLANK?8:(int)b);if(item>=1&&item<=8)inventory[item]=std::min(999,inventory[item]+1);set(x,y,z,AIR);rebuild();}
}
extern "C" JNIEXPORT void JNICALL Java_org_example_voxel16_NativeEngine_placeBlock(JNIEnv*,jobject){
 int x,y,z;target(x,y,z);if(get(x,y,z)==AIR && inventory[selected]>0){uint8_t block=(selected==8?PLANK:(uint8_t)selected);set(x,y,z,block);inventory[selected]--;rebuild();}
}
extern "C" JNIEXPORT jint JNICALL Java_org_example_voxel16_NativeEngine_getInventory(JNIEnv*,jobject,jint item){if(item<1||item>8)return 0;return inventory[item];}
extern "C" JNIEXPORT jint JNICALL Java_org_example_voxel16_NativeEngine_getMobHealth(JNIEnv*,jobject){return mobHealth;}
extern "C" JNIEXPORT jint JNICALL Java_org_example_voxel16_NativeEngine_getPlayerHealth(JNIEnv*,jobject){return playerHealth;}
extern "C" JNIEXPORT jboolean JNICALL Java_org_example_voxel16_NativeEngine_attackMob(JNIEnv*,jobject){
 float dx=playerX-mobX,dz=playerZ-mobZ;
 if(mobHealth<=0 || dx*dx+dz*dz>16.0f)return JNI_FALSE;
 mobHealth=std::max(0,mobHealth-1);mobHurt=0.22f;
 if(mobHealth==0){inventory[STONE]=std::min(999,inventory[STONE]+2);}
 rebuild();return JNI_TRUE;
}
extern "C" JNIEXPORT jboolean JNICALL Java_org_example_voxel16_NativeEngine_craftPlanks(JNIEnv*,jobject){
 if(inventory[WOOD]<2)return JNI_FALSE;inventory[WOOD]-=2;inventory[8]=std::min(999,inventory[8]+4);return JNI_TRUE;
}
extern "C" JNIEXPORT void JNICALL Java_org_example_voxel16_NativeEngine_saveWorld(JNIEnv*,jobject){
 if(savePath.empty())return;FILE*f=fopen(savePath.c_str(),"wb");if(!f)return;
 const char magic[4]={'V','X','W','4'};fwrite(magic,1,4,f);fwrite(inventory.data(),sizeof(int),inventory.size(),f);fwrite(&mobHealth,sizeof(int),1,f);fwrite(&playerHealth,sizeof(int),1,f);fwrite(&playerX,sizeof(float),1,f);fwrite(&playerY,sizeof(float),1,f);fwrite(&playerZ,sizeof(float),1,f);fwrite(&yaw,sizeof(float),1,f);fwrite(&mobX,sizeof(float),1,f);fwrite(&mobY,sizeof(float),1,f);fwrite(&mobZ,sizeof(float),1,f);fwrite(&mobDir,sizeof(float),1,f);fwrite(world.data(),1,world.size(),f);fclose(f);
}
extern "C" JNIEXPORT void JNICALL Java_org_example_voxel16_NativeEngine_loadWorld(JNIEnv*,jobject){
 if(savePath.empty())return;FILE*f=fopen(savePath.c_str(),"rb");if(!f)return;char m[4]{};float x,y,z,a;
 bool ok=fread(m,1,4,f)==4;
 bool isV4=ok && memcmp(m,"VXW4",4)==0;
 bool isV3=ok && memcmp(m,"VXW3",4)==0;
 bool isV2=ok && memcmp(m,"VXW2",4)==0;
 ok=ok && (isV4 || isV3 || isV2 || memcmp(m,"VXW1",4)==0);
 if(ok && (isV4 || isV3 || isV2))ok=fread(inventory.data(),sizeof(int),inventory.size(),f)==inventory.size();
 if(ok && (isV4 || isV3))ok=fread(&mobHealth,sizeof(int),1,f)==1 && fread(&playerHealth,sizeof(int),1,f)==1;
 if(ok)ok=fread(&x,4,1,f)==1&&fread(&y,4,1,f)==1&&fread(&z,4,1,f)==1&&fread(&a,4,1,f)==1;
 if(ok && isV4)ok=fread(&mobX,4,1,f)==1&&fread(&mobY,4,1,f)==1&&fread(&mobZ,4,1,f)==1&&fread(&mobDir,4,1,f)==1;
 if(ok)ok=fread(world.data(),1,world.size(),f)==world.size();
 fclose(f);
 if(ok){playerX=x;playerY=y;playerZ=z;yaw=a;mobHealth=std::clamp(mobHealth,0,5);playerHealth=std::clamp(playerHealth,1,20);mobX=std::clamp(mobX,1.0f,(float)W-2);mobY=std::clamp(mobY,1.0f,(float)H-2);mobZ=std::clamp(mobZ,1.0f,(float)D-2);rebuild();}
}
extern "C" JNIEXPORT void JNICALL Java_org_example_voxel16_NativeEngine_draw(JNIEnv*,jobject){
 worldClock+=0.0008f;float daylight=0.30f+0.70f*(0.5f+0.5f*sinf(worldClock*6.28318f));
 glClearColor(.035f+0.43f*daylight,.055f+0.64f*daylight,.12f+0.78f*daylight,1);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);if(!program||!vbo)return;
 float p[16],rY[16],rX[16],t[16],a[16],b[16],m[16];perspective(p,1.05f,(float)width/height,.1f,180);
 ry(rY,-yaw);rx(rX,-pitch*3.1415926f/180);tr(t,-playerX,-playerY-1.3f,-playerZ);
 mul(a,rY,t);mul(b,rX,a);mul(m,p,b);glUseProgram(program);glUniformMatrix4fv(mvpLoc,1,GL_FALSE,m);
 glBindBuffer(GL_ARRAY_BUFFER,vbo);glEnableVertexAttribArray(0);glEnableVertexAttribArray(1);
 glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,6*sizeof(float),(void*)0);glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,6*sizeof(float),(void*)(3*sizeof(float)));
 glDrawArrays(GL_TRIANGLES,0,(GLsizei)(verts.size()/6));
}
