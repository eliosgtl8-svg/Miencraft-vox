package org.example.voxel16

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.opengl.GLSurfaceView
import android.graphics.Color
import android.content.Context

class MainActivity : Activity() {
    private lateinit var game: EngineView
    private lateinit var status: TextView
    private var moveX = 0f
    private var moveZ = 0f
    private val hudHandler = Handler(Looper.getMainLooper())
    private val hudUpdate = object : Runnable {
        override fun run() {
            if (::game.isInitialized) game.queueEvent {
                val hp = NativeEngine.getPlayerHealth()
                val mob = NativeEngine.getMobHealth()
                postStatus("Vida: $hp/20  ·  Criatura: $mob/5  ·  ${inventoryText()}")
            }
            hudHandler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        NativeEngine.setWorldPath(filesDir.absolutePath + "/world.vxw")
        val root = FrameLayout(this)
        game = EngineView(this)
        root.addView(game, FrameLayout.LayoutParams(-1, -1))
        status = TextView(this).apply {
            text = "Voxel16 · Supervivencia de prueba · combate y ciclo día/noche"
            setTextColor(Color.WHITE); textSize = 13f
            setShadowLayer(4f, 1f, 1f, Color.BLACK)
            setPadding(18, 12, 18, 12)
        }
        root.addView(status, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val up = holdButton("▲", { moveZ = -1f }, { moveZ = 0f })
        val mid = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val leftBtn = holdButton("◀", { moveX = -1f }, { moveX = 0f })
        val downBtn = holdButton("▼", { moveZ = 1f }, { moveZ = 0f })
        val rightBtn = holdButton("▶", { moveX = 1f }, { moveX = 0f })
        mid.addView(leftBtn); mid.addView(downBtn); mid.addView(rightBtn)
        left.addView(up); left.addView(mid)
        val lp = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply { leftMargin=22; bottomMargin=24 }
        root.addView(left, lp)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity=Gravity.CENTER }
        actions.addView(button("SALTAR") { game.queueEvent { NativeEngine.jump() } })
        actions.addView(button("ROMPER") { game.queueEvent { NativeEngine.breakBlock() } })
        actions.addView(button("ATACAR CRIATURA") { game.queueEvent { val hit=NativeEngine.attackMob(); postStatus(if(hit) "Golpe acertado · vida criatura: ${NativeEngine.getMobHealth()}/5" else "Acércate a la criatura para atacar") } })
        actions.addView(button("PONER") { game.queueEvent { NativeEngine.placeBlock() } })
        actions.addView(button("BLOQUE +") { game.queueEvent { NativeEngine.selectNextBlock(1) }; status.text="Bloque cambiado · inventario disponible abajo" })
        actions.addView(button("BLOQUE -") { game.queueEvent { NativeEngine.selectNextBlock(-1) } })
        actions.addView(button("GUARDAR") { game.queueEvent { NativeEngine.saveWorld() }; status.text="Mundo guardado" })
        actions.addView(button("CARGAR") { game.queueEvent { NativeEngine.loadWorld() }; status.text="Mundo cargado" })
        actions.addView(button("FABRICAR x4 TABLAS") {
            game.queueEvent { val ok = NativeEngine.craftPlanks(); postStatus(if(ok) "Fabricaste 4 tablas" else "Necesitas 2 bloques de madera") }
        })
        actions.addView(button("INVENTARIO") { game.queueEvent { postStatus(inventoryText()) } })
        val rp = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { rightMargin=18; bottomMargin=18 }
        root.addView(actions, rp)
        setContentView(root)
        hudHandler.postDelayed(hudUpdate, 1000L)
        game.setMoveProvider { moveX to moveZ }
    }

    private fun inventoryText(): String {
        val names = listOf("Césped","Tierra","Piedra","Madera","Hojas","Arena","Agua","Tablas")
        return names.mapIndexed { i, n -> "$n: ${NativeEngine.getInventory(i+1)}" }.joinToString("  ·  ")
    }
    private fun postStatus(message: String) { runOnUiThread { status.text = message } }

    private fun holdButton(label: String, down: () -> Unit, up: () -> Unit): Button = Button(this).apply {
        text=label; textSize=11f; setPadding(8,2,8,2); isAllCaps=false
        setOnTouchListener { _, event ->
            when(event.actionMasked){
                MotionEvent.ACTION_DOWN -> down()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> up()
            }
            true
        }
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text=label; textSize=11f; setPadding(8,2,8,2); isAllCaps=false
        setOnClickListener { action() }
    }

    override fun onPause(){ hudHandler.removeCallbacks(hudUpdate); super.onPause(); game.onPause() }
    override fun onResume(){ super.onResume(); game.onResume(); hudHandler.post(hudUpdate) }
    override fun onDestroy(){ hudHandler.removeCallbacks(hudUpdate); super.onDestroy() }
}

private class EngineView(ctx: Context) : GLSurfaceView(ctx) {
    private var lastX=0f; private var lastY=0f
    private var moveProvider: (() -> Pair<Float,Float>)? = null
    init {
        setEGLContextClientVersion(3)
        preserveEGLContextOnPause=true
        setRenderer(VoxelRenderer { moveProvider?.invoke() ?: (0f to 0f) })
        renderMode=RENDERMODE_CONTINUOUSLY
    }
    fun setMoveProvider(p: () -> Pair<Float,Float>) { moveProvider=p }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when(e.actionMasked){
            MotionEvent.ACTION_DOWN->{lastX=e.x;lastY=e.y}
            MotionEvent.ACTION_MOVE->{
                val dx=e.x-lastX; val dy=e.y-lastY
                queueEvent { NativeEngine.look(dx,dy) }
                lastX=e.x;lastY=e.y
            }
        }
        return true
    }
}
