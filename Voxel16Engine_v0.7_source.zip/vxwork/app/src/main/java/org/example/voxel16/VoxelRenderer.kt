package org.example.voxel16
import android.opengl.GLSurfaceView
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
class VoxelRenderer(private val movement: () -> Pair<Float,Float>) : GLSurfaceView.Renderer {
    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) = NativeEngine.init()
    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) = NativeEngine.resize(width,height)
    override fun onDrawFrame(gl: GL10?) {
        val (x,z)=movement()
        NativeEngine.move(x,z,0.016f)
        NativeEngine.draw()
    }
}
