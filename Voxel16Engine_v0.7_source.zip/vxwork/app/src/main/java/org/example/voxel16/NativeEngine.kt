package org.example.voxel16
object NativeEngine {
    init { System.loadLibrary("voxelengine") }
    external fun setWorldPath(path: String)
    external fun init()
    external fun resize(width: Int, height: Int)
    external fun draw()
    external fun look(dx: Float, dy: Float)
    external fun move(x: Float, z: Float, dt: Float)
    external fun jump()
    external fun breakBlock()
    external fun placeBlock()
    external fun selectNextBlock(direction: Int)
    external fun saveWorld()
    external fun loadWorld()
    external fun getInventory(item: Int): Int
    external fun craftPlanks(): Boolean
    external fun attackMob(): Boolean
    external fun getMobHealth(): Int
    external fun getPlayerHealth(): Int
}
